let grade =+prompt("enter your marks");

if (grade >= 90) {
    console.log("Marks are "+grade+" and grade is A");
  } else if (grade >= 80) {
    console.log("Marks are "+grade+" and grade is B");
  } else if (grade >= 70) {
    console.log("Marks are "+grade+" and grade is C");
  } else if (grade >= 60) {
    console.log("Marks are "+grade+" and grade is D");
  } else {
    console.log("Marks are "+grade+" and grade is F");
  }
  