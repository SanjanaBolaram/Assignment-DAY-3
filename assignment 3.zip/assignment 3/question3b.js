//USING TERNARY

let grade =+prompt("enter your marks");
console.log((grade >= 90)? 'Marks are '+grade+' and grade is A':(grade >= 80)? 'Marks are '+grade+' and grade is B':(grade >= 70)? 'Marks are '+grade+' and grade is C': (grade >= 60)? 'Marks are '+grade+' and grade is D':'Marks are '+grade+' and grade is F');