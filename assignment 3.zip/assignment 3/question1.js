let num = +prompt("enter a number");
if(num % 2 == 0) {
   console.log('the number is' +num+' and the number is even');
   
} else {
   console.log('the number is ' +num+' and the number is odd');
} 